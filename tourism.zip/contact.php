<?php
// 1. ከዳታቤዝ ጋር ማገናኘት (db.php ካለህ እሱን መጠቀም ትችላለህ)

$conn = new mysqli("localhost", "root", "", "tourism_final");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }


$success_msg = "";
$error_msg = "";

// 2. ሰብሚት ሲደረግ መረጃውን መቀበል
if(isset($_POST['send_message'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    $sql = "INSERT INTO contact_messages (name, email, message) VALUES ('$name', '$email', '$message')";

    if(mysqli_query($conn, $sql)) {
        $success_msg = "መልዕክትዎ በትክክል ተልኳል! አድሚኑ በቅርቡ ያገኝዎታል።";
    } else {
        $error_msg = "ይቅርታ፣ ስህተት ተፈጥሯል። እንደገና ይሞክሩ።";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Contact Us - ET-TOUR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        
        .contact-container { width: 85%; margin: 60px auto; display: grid; grid-template-columns: 1fr 1fr; gap: 50px; }
        .contact-info { background: #27ae60; color: white; padding: 50px; border-radius: 20px; }
         .info-item { display: flex; align-items: center; margin-bottom: 25px; }
        .info-item i { font-size: 24px; margin-right: 15px; }
        .contact-form { background: white; padding: 50px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .input-group { margin-bottom: 20px; }
        .input-group input, .input-group textarea { width: 100%; padding: 15px; border: 1px solid #ddd; border-radius: 10px; outline: none; }
        .btn-send { background: #27ae60; color: white; padding: 15px 30px; border: none; border-radius: 10px; cursor: pointer; width: 100%; font-size: 16px; font-weight: bold; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 10px; text-align: center; }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
        footer { background: #1a252f; color: white; padding: 40px; text-align: center; }
    </style>
</head>
<body>

     <div class="navbar">
        <div class="brand">
            <a href="index.php"><i class="fa-solid fa-earth-africa"></i> ስልጤ-Tour</a>
        </div>

        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="about.php">About Us</a>
            <a href="tour_package.php">Tour Packages</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="nav-auth">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="dashboard.php"><i class="fa fa-user"></i> My Dashboard</a>
                <a href="logout.php" style="background:#d9534f;">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
                <a href="admin_login.php" style="background:#333; border:1px solid #555;">Admin</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="contact-container">
        <div class="contact-info">
            <h2>ስልጤ የጉብኝት ቦታ</h2>
            <p>ጥያቄ አለዎት? ወይስ ስለ ስልጤ ዞን ጉብኝትዎ ተጨማሪ መረጃ ይፈልጋሉ? እኛን ለማግኘት ወደኋላ አይበሉ! የእርስዎ አስተያየት እና ጥያቄ ለሥራችን መሳካት ትልቅ ዋጋ አለው።.</p>
            <br><br>
            <div class="info-item"><i class="fas fa-phone"></i> +251 911 00 00 00</div>
            <div class="info-item"><i class="fas fa-envelope"></i> info@silte_tour.com</div>
            <div class="info-item"><i class="fas fa-map-marker-alt"></i> አድራሻ፦ ስልጤ ዞን፣ ወራቤ ከተማ፣ ኢትዮጵያ</div>
            <div class="info-item"><i class="fab fa-facebook-f"></i> <a href="https://www.facebook.com/profile.php?id=100" target="_blank">Facebook</a></div>
            <div class="info-item"><i class="fab fa-instagram"></i> <a href="https://www.instagram.com/profile/" target="_blank">Instagram</a></div>
            <div class="info-item"><i class="fab fa-twitter"></i> <a href="https://twitter.com/profile" target="_blank">Twitter</a></div>
            <div class="info-item"><i class="fab fa-youtube"></i> <a href="https://www.youtube.com/channel/UC" target="_blank">Youtube</a></div>
            
        </div>

        <div class="contact-form">
            <h2>Send a Message</h2>
            
            <?php if($success_msg): ?> <div class="alert success"><?php echo $success_msg; ?></div> <?php endif; ?>
            <?php if($error_msg): ?> <div class="alert error"><?php echo $error_msg; ?></div> <?php endif; ?>

            <form action="contact.php" method="POST">
                <div class="input-group"><input type="text" name="name" placeholder="Your Name" required></div>
                <div class="input-group"><input type="email" name="email" placeholder="Your Email" required></div>
                <div class="input-group"><textarea name="message" rows="5" placeholder="Your Message" required></textarea></div>
                <button type="submit" name="send_message" class="btn-send">Send Message</button>
            </form>
        </div>
    </div>

    <footer><p>&copy; 2026 ስልጤ-TOUR Management System</p></footer>
</body>
</html>