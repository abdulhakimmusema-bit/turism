<?php
session_start();
include 'db.php';
if (!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }

// አዲስ Package ሲጨመር
if (isset($_POST['add_package'])) {
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];
    
    // ምስል Upload Logic
    $image = $_FILES['image']['name'];
    $target = "images/" . basename($image);
    
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $sql = "INSERT INTO packages (package_name, description, price, image_file) VALUES ('$name', '$desc', '$price', '$image')";
        $conn->query($sql);
        $msg = "Package Added Successfully!";
    } else {
        $msg = "Image Upload Failed!";
    }
}

// Package ለማጥፋት
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM packages WHERE package_id=$id");
    header("Location: manage_packages.php");
}
?>

<!DOCTYPE html>
<html>
<head><title>Manage Packages</title><link rel="stylesheet" href="css/style.css"></head>
<body>
    <div style="padding: 20px;">
        <h2>Manage Tour Packages</h2>
        <a href="admin_dashboard.php" class="btn">Back to Dashboard</a>
        <hr>
        
        <div style="background:#f9f9f9; padding:20px; border:1px solid #ddd; margin-bottom:20px;">
            <h3>Add New Package</h3>
            <form method="post" enctype="multipart/form-data"> <input type="text" name="name" placeholder="Package Name" required style="width:30%;">
                <input type="number" name="price" placeholder="Price (ETB)" required style="width:20%;">
                <input type="file" name="image" required style="width:30%;">
                <br><br>
                <textarea name="description" placeholder="Description" required style="width:100%; height:100px;"></textarea>
                <br><br>
                <button type="submit" name="add_package" class="btn" style="background:#27ae60;">Add Package</button>
            </form>
        </div>

        <table boarder="1" cellpadding="10" style="width:100%; border-collapse:collapse;">
            <tr><th>Image</th><th>Name</th><th>Price</th><th>Action</th></tr>
            <?php
            $res = $conn->query("SELECT * FROM packages");
            while ($row = $res->fetch_assoc()) {
                echo "<tr>";
                echo "<td><img src='images/".$row['image_file']."' width='50'></td>";
                echo "<td>".$row['package_name']."</td>";
                echo "<td>".$row['price']."</td>";
                echo "<td><a href='manage_packages.php?delete=".$row['package_id']."' style='color:red;' onclick='return confirm(\"Are you sure?\")'>Delete</a></td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>