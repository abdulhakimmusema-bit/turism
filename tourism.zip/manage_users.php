<?php
session_start();
include 'db.php';

// አድሚን መሆኑን ማረጋገጥ
if (!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }

// User ለማጥፋት
// User ለማጥፋት
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // ደረጃ 1: መጀመሪያ ከዚህ ተጠቃሚ ጋር የተያያዙ ክፍያዎችን (Payments) እናጥፋ
    // (ክፍያ ከሌለ ችግር የለውም፣ ዝም ብሎ ያልፋል)
    $conn->query("DELETE FROM payments WHERE booking_id IN (SELECT booking_id FROM bookings WHERE user_id=$id)");

    // ደረጃ 2: ቀጥሎ የተጠቃሚውን ቦታ ማስያዣዎች (Bookings) እናጥፋ
    $conn->query("DELETE FROM bookings WHERE user_id=$id");

    // ደረጃ 3: አሁን ምንም ታሪክ ስለሌለው ተጠቃሚውን (User) ማጥፋት እንችላለን
    if($conn->query("DELETE FROM users WHERE user_id=$id")) {
        echo "<script>alert('User and all their history deleted successfully!'); window.location='manage_users.php';</script>";
    } else {
        echo "<script>alert('Error deleting user: " . $conn->error . "'); window.location='manage_users.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #2c3e50; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div style="padding: 20px;">
        <h2>Manage Users (የተመዘገቡ ደንበኞች)</h2>
        <a href="admin_dashboard.php" class="btn" style="background:#555;">&laquo; Back to Dashboard</a>
        
        <table>
            <tr>
                <th>User ID</th>
                <th>Full Name (Username)</th>
                <th>Email Address</th>
                <th>Registered Date</th>
                <th>Action</th>
            </tr>
            
            <?php
            $sql = "SELECT * FROM users ORDER BY user_id DESC";
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td><?php echo $row['user_id']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['created_at']; ?></td> <td>
                            <a href="manage_users.php?delete=<?php echo $row['user_id']; ?>" 
                               onclick="return confirm('Are you sure? This will delete the user.');" 
                               style="color: white; background: red; padding: 5px 10px; text-decoration: none; border-radius: 4px;">Delete</a>
                        </td>
                    </tr>
                    <?php
                }
            } else {
                echo "<tr><td colspan='5' style='text-align:center;'>No users registered yet.</td></tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>