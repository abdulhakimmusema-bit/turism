<?php
session_start();
include 'db.php';

// አድሚን መሆኑን ማረጋገጥ
if (!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }

// Booking ለማጥፋት (Delete)
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // ደረጃ 1: መጀመሪያ ከዚህ Booking ጋር የተያያዘውን ክፍያ (Payment) እናጥፋ
    $conn->query("DELETE FROM payments WHERE booking_id=$id"); 

    // ደረጃ 2: አሁን ክፍያው ስለጠፋ Booking ማጥፋት እንችላለን
    if($conn->query("DELETE FROM bookings WHERE booking_id=$id")) {
        echo "<script>alert('Booking and its payment history deleted successfully'); window.location='manage_bookings.php';</script>";
    } else {
        // ማሳሰቢያ፡ ይህ ስህተት የሚመጣው ሌላ ያልተጠበቀ Foreign Key ካለ ብቻ ነው
        echo "<script>alert('Error deleting booking: " . $conn->error . "');</script>"; 
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Bookings</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #2c3e50; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .status-confirmed { color: green; font-weight: bold; }
        .status-pending { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <div style="padding: 20px;">
        <h2>Manage Bookings (የተያዙ ቦታዎች)</h2>
        <a href="admin_dashboard.php" class="btn" style="background:#555;">&laquo; Back to Dashboard</a>
        
        <table>
            <tr>
                <th>ID</th>
                <th>User Name</th>
                <th>Package</th>
                <th>Travel Date</th>
                <th>Travelers</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            
            <?php
            // 3ቱን ሰንጠረዦች (Bookings, Users, Packages) እናገናኛለን (JOIN)
            $sql = "SELECT b.*, u.username, p.package_name 
                    FROM bookings b 
                    JOIN users u ON b.user_id = u.user_id 
                    JOIN packages p ON b.package_id = p.package_id 
                    ORDER BY b.booking_id DESC"; // በቅርብ የተያዘው ከላይ እንዲሆን
            
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $statusClass = ($row['status'] == 'Confirmed') ? 'status-confirmed' : 'status-pending';
                    ?>
                    <tr>
                        <td>#<?php echo $row['booking_id']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['package_name']; ?></td>
                        <td><?php echo $row['travel_date']; ?></td>
                        <td><?php echo $row['travelers']; ?></td>
                        <td><?php echo number_format($row['total_price'], 2); ?> ETB</td>
                        <td class="<?php echo $statusClass; ?>"><?php echo $row['status']; ?></td>
                        <td>
                            <a href="manage_bookings.php?delete=<?php echo $row['booking_id']; ?>" 
                               onclick="return confirm('Are you sure you want to delete this booking?');" 
                               style="color: white; background: red; padding: 5px 10px; text-decoration: none; border-radius: 4px;">Delete</a>
                        </td>
                    </tr>
                    <?php
                }
            } else {
                echo "<tr><td colspan='8' style='text-align:center;'>No bookings found.</td></tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>