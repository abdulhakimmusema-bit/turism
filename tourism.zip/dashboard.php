<?php
session_start();
include 'db.php';
if(!isset($_SESSION['user_id'])){ header("Location: login.php"); exit; }
$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="css/style.css"></head>
<body>
    <div class="navbar"><a href="index.php">Back to Home</a></div>
    <div class="container">
        <h2>My Booking History</h2>
        <table border="1" cellpadding="10" style="width:100%; border-collapse:collapse;">
            <tr>
                <th>Package</th>
                <th>Date</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <?php
            // Join በማድረግ የጥቅሉን ስም እናመጣለን
            $sql = "SELECT b.*, p.package_name FROM bookings b 
                    JOIN packages p ON b.package_id = p.package_id 
                    WHERE b.user_id = $user_id";
            $result = $conn->query($sql);
            
            while($row = $result->fetch_assoc()){
            ?>
            <tr>
                <td><?php echo $row['package_name']; ?></td>
                <td><?php echo $row['travel_date']; ?></td>
                <td><?php echo $row['total_price']; ?> ETB</td>
                <td class="<?php echo ($row['status']=='Pending')?'status-pending':'status-confirmed'; ?>">
                    <?php echo $row['status']; ?>
                </td>
                <td>
                    <?php if($row['status'] == 'Pending'): ?>
                        <a href="pay.php?booking_id=<?php echo $row['booking_id']; ?>&amount=<?php echo $row['total_price']; ?>" class="btn btn-pay">Pay Now</a>
                    <?php else: ?>
                        ✅ Paid
                    <?php endif; ?>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>