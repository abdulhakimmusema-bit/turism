<?php
session_start();
// 1. የዳታቤዝ ግንኙነት ፋይልን ማካተት
include 'db.php'; 

// 2. አድሚን መሆኑን ማረጋገጥ (ካልሆነ ወደ login ይላካል)
if (!isset($_SESSION['admin_id'])) { 
    header("Location: admin_login.php"); 
    exit; 
}

// 3. መልዕክት ለመሰረዝ (Delete Logic)
if(isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    // ደህንነቱ የተጠበቀ መሰረዝ
    $id = mysqli_real_escape_string($conn, $id);
    $delete_query = "DELETE FROM contact_messages WHERE id = '$id'";
    
    if(mysqli_query($conn, $delete_query)) {
        echo "<script>alert('መልዕክቱ በትክክል ተሰርዟል!'); window.location='view_messages.php';</script>";
    }
}

// 4. ሁሉንም መልዕክቶች ከዳታቤዝ ማምጣት
$sql = "SELECT * FROM contact_messages ORDER BY submitted_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Messages - Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f4f7f6; margin: 0; display: flex; }
        
        /* Dashboard Sidebar Style */
        .sidebar { width: 250px; background: #2c3e50; min-height: 100vh; color: white; padding: 20px; position: fixed; }
        .sidebar a { display: block; color: #bdc3c7; padding: 15px; text-decoration: none; border-bottom: 1px solid #34495e; }
        .sidebar a:hover { color: white; background: #34495e; }
        
        .main-content { margin-left: 270px; padding: 30px; flex: 1; }
        .msg-table { width: 100%; border-collapse: collapse; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .msg-table th, .msg-table td { padding: 15px; text-align: left; border-bottom: 1px solid #eee; }
        .msg-table th { background: #27ae60; color: white; }
        .btn-delete { color: #e74c3c; cursor: pointer; text-decoration: none; }
        .btn-delete:hover { color: #c0392b; }
        h1 { color: #2c3e50; margin-bottom: 20px; }
    </style>
</head>
<body>

    <div class="sidebar">
        <h3><i class="fa fa-cogs"></i> Admin Panel</h3>
        <a href="admin_dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a>
        <a href="manage_packages.php"><i class="fa fa-map"></i> Manage Packages</a>
        <a href="manage_bookings.php"><i class="fa fa-book"></i> Manage Bookings</a>
        <a href="manage_users.php"><i class="fa fa-users"></i> Manage Users</a>
        <a href="view_messages.php" style="background:#34495e; color:white;"><i class="fa fa-envelope"></i> Manage Messages</a>
        <a href="logout.php" style="color:#e74c3c;"><i class="fa fa-sign-out"></i> Logout</a>
    </div>

    <div class="main-content">
        <h1><i class="fa fa-envelope-open"></i> Customer Messages</h1>
        
        <table class="msg-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($row['message'])); ?></td>
                        <td><?php echo date('M d, Y', strtotime($row['submitted_at'])); ?></td>
                        <td>
                            <a href="view_messages.php?delete_id=<?php echo $row['id']; ?>" 
                               onclick="return confirm('እርግጠኛ ነህ ይህ መልዕክት ይጥፋ?')" class="btn-delete">
                                <i class="fa fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align:center;">ምንም የተላከ መልዕክት የለም።</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>