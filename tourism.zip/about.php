<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - ET-TOUR</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Hero Section */
        .hero {
            height: 50vh;
            background: linear-gradient(rgba(241, 69, 244, 0.6), rgba(165, 248, 227, 0.6)), url('images/ilovewera.webp') center/cover;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
        }

        .hero h1 {
            font-size: 50px;
            text-transform: uppercase;
        }

        /* Content Area */
        .container {
            width: 85%;
            margin: 80px auto;
        }

        .about-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
        }

        .about-img img {
            width: 100%;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(243, 17, 17, 0.2);
        }

        .about-text h2 {
            color: #27ae60;
            font-size: 36px;
            margin-bottom: 20px;
        }

        .about-text p {
            line-height: 1.8;
            color: #555;
            font-size: 18px;
        }

        /* Stats Section */
        .stats {
            background: #2c3e50;
            color: white;
            padding: 60px 0;
            margin-top: 50px;
            border-radius: 20px;
            display: flex;
            justify-content: space-around;
            text-align: center;
        }

        .stat-item h3 {
            font-size: 40px;
            color: #27ae60;
        }

        /* Footer */
        footer {
            background: #1a252f;
            color: white;
            padding: 40px;
            text-align: center;
            margin-top: 80px;
        }
    </style>
</head>

<body>

   <div class="navbar">
        <div class="brand">
            <a href="index.php"><i class="fa-solid fa-earth-africa"></i> ስልጤ-Tour</a>
        </div>

        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="about.php">About Us</a>
            <a href="tour_package.php">Tour Packages</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="nav-auth">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="dashboard.php"><i class="fa fa-user"></i> My Dashboard</a>
                <a href="logout.php" style="background:#d9534f;">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
                <a href="admin_login.php" style="background:#333; border:1px solid #555;">Admin</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="hero">
    </div>

    <div class="container">
        <div class="about-grid">
            <div class="about-img">
                <img src="images/wenz3.jpeg" alt="Ethiopian Culture">
            </div>
            <div class="about-text">
                <p>
                    <h2>እንኳን ወደ ስልጤ ዞን ዲጂታል የቱሪዝም መድረክ በደህና መጡ!</h2>
እኛ የስልጤን ዞን ተፈጥሯዊ ውበት፣ ታሪካዊ ቅርሶች እና ደማቅ ባህል ለአለም ለማስተዋወቅ የተቋቋምን ቀዳሚ የዲጂታል ቱሪዝም መፍትሔ አቅራቢ ነን። የእኛ ሲስተም ጎብኚዎች ያለምንም እንግልት የዞኑን ምርጥ መዳረሻዎች እንዲያውቁ እና ጉዟቸውን እንዲያቅዱ ለማገዝ የተነደፈ ነው።
<br><br>
<h2>ራእያችን</h2>
ስልጤ በኢትዮጵያ ውስጥ ካሉ ቀዳሚ የቱሪስት መዳረሻዎች አንዷ እንድትሆን ማድረግ እና ቱሪዝምን በዘመናዊ ቴክኖሎጂ በመደገፍ የአካባቢውን ኢኮኖሚ ማሳደግ ነው።
<br><br>
<h2>ምን እንሰራለን?</h2>
መዳረሻዎችን ማስተዋወቅ፡ እንደ ድንቁ የሀረ ሼጣን ሐይቅ፣ ሰፊው አባያ ሐይቅ፣ የወራቤ ወንዝ ዳርቻ እና ጥንታዊው የስልጤ ሙዚየም ያሉ ቦታዎችን መረጃ ለጎብኚዎች እናቀርባለን።

ቀላል ጉዞ፡ ቱሪስቶች ስለ ቦታዎቹ በቂ መረጃ አግኝተው በልበ ሙሉነት እንዲንቀሳቀሱ እናደርጋለን።

ተለዋዋጭ አሰራር፡ ሲስተማችን በአስተዳዳሪዎች አማካኝነት አዳዲስ መዳረሻዎችን በየጊዜው እንዲያካትት ተደርጎ የተሰራ በመሆኑ፣ ሁልጊዜም ትክክለኛ እና ወቅታዊ መረጃ ተደራሽ ነው።
<br><br>
<h2>ለምን እኛን ይመርጣሉ?</h2>
ስልጤ የንግድ፣ የሀይማኖት እና የሰላም ተምሳሌት የሆነ ህዝብ የሚኖርባት ምድር ናት። እኛ ይህን እሴት ጠብቀን፣ በቴክኖሎጂ የታገዘ መረጃ በማቅረብ ጉዞዎ የማይረሳ ትውስታ እንዲሆን እንሰራለን።
<br><br>
<h2>የእኛ እሴቶች</h2>
እንግዳ ተቀባይነት፡ ለጎብኚዎቻችን የምናቀርበው መረጃ እንደ ስልጤ ህዝብ ሁሉ ሞቅ ያለ እና ቅን ነው።

ታማኝነት፡ ስለ መዳረሻዎች የምንሰጠው መረጃ ትክክለኛ እና ጥራት ያለው ነው።

ፈጠራ፡ የቱሪዝም ዘርፉን ከዲጂታል አለም ጋር በማስተሳሰር ቀላል ተደራሽነትን እንፈጥራለን።</p>
            </div>
        </div>

        <div class="stats">
            <div class="stat-item">
                <h3>14</h3>
                <p>Travelers</p>
            </div>
            <div class="stat-item">
                <h3>100</h3>
                <p>Packages</p>
            </div>
            <div class="stat-item">
                <h3>3</h3>
                <p>Destinations</p>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2026 ስልጤ-TOUR Management System | All Rights Reserved.</p>
    </footer>

</body>

</html>