<?php
// ስህተቶችን እንዲያሳይ እንፍቀድለት (For Debugging)
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'db.php'; 

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']); // trim - ክፍት ቦታዎችን ለማጥፋት
    $password = trim($_POST['password']); 

    // 1. መጀመሪያ User መኖሩን እንይ
    $stmt = $conn->prepare("SELECT admin_id, username, password FROM admins WHERE username=?");
    if (!$stmt) {
        die("SQL Error: " . $conn->error); // SQL ላይ ችግር ካለ ይነግረናል
    }
    
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        
        // 2. የተገኘውን መረጃ ለሙከራ እንየው (Debug)
        // ይህንን ወደፊት እናጠፋዋለን፣ አሁን ግን ችግሩን ለማየት ይጠቅማል
        echo "<div style='background:yellow; padding:10px; border:1px solid orange;'>";
        echo "<strong>Debug Info:</strong><br>";
        echo "User Found: " . $row['username'] . "<br>";
        echo "Stored Hash: " . substr($row['password'], 0, 10) . "...<br>";
        
        // 3. ፓስወርዱን እናወዳድር
        if (password_verify($password, $row['password'])) {
            echo "<span style='color:green'>Password Matched! Redirecting...</span>";
            $_SESSION['admin_id'] = $row['admin_id'];
            $_SESSION['admin_user'] = $row['username'];
            header("Location: admin_dashboard.php");
            exit();
        } else {
            echo "<span style='color:red'>Password Verify FAILED.</span>";
            $msg = "የይለፍ ቃል ስህተት ነው (Invalid Password)";
        }
        echo "</div>";
    } else {
        $msg = "ይህ User በዳታቤዝ ውስጥ የለም (User not found).";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login Debug</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body style="background:#f4f4f4;">
    <div class="container" style="max-width:400px; margin-top:50px; background:white; padding:30px; border-radius:8px;">
        <h2 style="text-align:center;">Admin Login</h2>
        
        <?php if($msg != ""): ?>
            <p style="background: #ffdddd; color: red; padding: 10px; border: 1px solid red;"><?php echo $msg; ?></p>
        <?php endif; ?>

        <form method="post">
            <label>Username:</label>
            <input type="text" name="username" required style="width:100%; padding:8px; margin-bottom:10px;">
            
            <label>Password:</label>
            <input type="password" name="password" required style="width:100%; padding:8px; margin-bottom:10px;">
            
            <button type="submit" class="btn" style="width:100%; background:#333;">Login</button>
        </form>
        <p><a href="index.php">Back to Home</a></p>
    </div>
</body>
</html>