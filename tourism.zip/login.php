<?php
session_start();
include 'db.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // 1. ኢሜይሉን ፈልግ
    $stmt = $conn->prepare("SELECT user_id, username, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        
        // 2. ፓስወርዱን አረጋግጥ (Verify Hash)
        if (password_verify($password, $row['password'])) {
            // ትክክል ነው! ሴሽን ፍጠር
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['username'] = $row['username'];
            
            // ወደ ዋናው ገጽ (ወይም ዳሽቦርድ) ላከው
            header("Location: index.php"); 
            exit();
        } else {
            $message = "የተሳሳተ ፓስወርድ ነው (Incorrect Password)።";
        }
    } else {
        $message = "ይህ ኢሜይል አልተመዘገበም (User not found)።";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login - Ethiopian Tourism</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .form-container { max-width: 500px; margin: 100px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        input[type="email"], input[type="password"] { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; box-sizing: border-box; }
    </style>
</head>
<body>
    <div class="navbar"><a href="index.php">Home</a></div>
    
    <div class="form-container">
        <h2 style="text-align:center;">Login (ግባ)</h2>
        <p style="color:red; text-align:center;"><?php echo $message; ?></p>
        
        <form method="post" action="">
            <label>Email:</label>
            <input type="email" name="email" required>
            
            <label>Password:</label>
            <input type="password" name="password" required>
            
            <button type="submit" class="btn" style="width:100%;">Login</button>
        </form>
        <p style="text-align:center;">Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>
</html>