<?php
session_start();
include 'db.php'; // የዳታቤዝ ግንኙነት

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // 1. ኢሜይሉ ከዚህ በፊት የተመዘገበ መሆኑን ማረጋገጥ
    $check_email = $conn->query("SELECT user_id FROM users WHERE email='$email'");
    
    if ($check_email->num_rows > 0) {
        $message = "ይህ ኢሜይል አስቀድሞ ተመዝግቧል! እባክዎ ይግቡ (Login)።";
    } else {
        // 2. ፓስወርዱን ደብቅ (Hash Password)
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // 3. ወደ ዳታቤዝ አስገባ (Using Prepared Statement for Security)
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashed_password);

        if ($stmt->execute()) {
            // ምዝገባው ከተሳካ ወደ Login ገጽ እንልከዋለን
            echo "<script>alert('ምዝገባዎ ተሳክቷል! አሁን መግባት ይችላሉ።'); window.location='login.php';</script>";
        } else {
            $message = "ስህተት: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register - Ethiopian Tourism</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* ለፎርም ውበት */
        .form-container { max-width: 400px; margin: 50px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        input[type="text"], input[type="email"], input[type="password"] { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; box-sizing: border-box; }
    </style>
</head>
<body>
    <div class="navbar"><a href="index.php">Home</a></div>
    
    <div class="form-container">
        <h2 style="text-align:center;">Register (ተመዝገብ)</h2>
        <p style="color:red; text-align:center;"><?php echo $message; ?></p>
        
        <form method="post" action="">
            <label>Full Name (ሙሉ ስም):</label>
            <input type="text" name="username" required>
            
            <label>Email (ኢሜይል):</label>
            <input type="email" name="email" required>
            
            <label>Password (የይለፍ ቃል):</label>
            <input type="password" name="password" required>
            
            <button type="submit" class="btn" style="width:100%;">Register</button>
        </form>
        <p style="text-align:center;">Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body>
</html>