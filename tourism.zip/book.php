<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user_id'])){ header("Location: login.php"); exit; }

$package_id = $_GET['id'];
// የጥቅል መረጃን ማምጣት (ዋጋን ለማወቅ)
$pkg = $conn->query("SELECT * FROM packages WHERE package_id=$package_id")->fetch_assoc();

if(isset($_POST['confirm_booking'])){
    $user_id = $_SESSION['user_id'];
    $date = $_POST['date'];
    $travelers = $_POST['travelers'];
    $total = $pkg['price'] * $travelers;

    // እዚህ ጋር Status 'Pending' ብለን ነው የምናስገባው
    $sql = "INSERT INTO bookings (user_id, package_id, travel_date, travelers, total_price, status) 
            VALUES ('$user_id', '$package_id', '$date', '$travelers', '$total', 'Pending')";
    
    if($conn->query($sql)){
        // በተሳካ ሁኔታ ሲያዝ ወደ Dashboard እንልከዋለን (ለክፍያ)
        header("Location: dashboard.php");
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="css/style.css"></head>
<body>
    <div class="container" style="max-width: 500px; margin-top:50px;">
        <h2>Book: <?php echo $pkg['package_name']; ?></h2>
        <form method="post">
            <label>Date of Travel:</label><br>
            <input type="date" name="date" required style="width:100%; padding:8px;"><br><br>
            
            <label>Number of Travelers:</label><br>
            <input type="number" name="travelers" value="1" min="1" required style="width:100%; padding:8px;"><br><br>
            
            <button type="submit" name="confirm_booking" class="btn">Confirm Booking</button>
        </form>
    </div>
</body>
</html>