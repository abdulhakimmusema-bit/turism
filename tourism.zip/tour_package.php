<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    .mySlides img {
      height: 400px;
    }



    div.gallery {
      border: 1px solid #ccc;
      display: flex;
    }

    div.gallery:hover {
      border: 1px solid #777;
    }

    div.gallery img {
      width: 400px;
      height: 250px;
    }

    div.desc {
      padding: 15px;
      text-align: center;
    }

    * {
      box-sizing: border-box;
    }

    .responsive {
      margin-top: 5%;
      margin-left: 8%;
      padding: 0 12px;
      float: left;
      width: 85%;
      background-color: #f6ebebff;


    }

    @media only screen and (max-width: 700px) {
      .responsive {
        width: 49.99999%;
        margin: 6px 0;
      }
    }

    @media only screen and (max-width: 500px) {
      .responsive {
        width: 100%;
      }
    }

    .clearfix:after {
      content: "";
      display: table;
      clear: both;
    }

    .text {
      text-align: center;
      color: #a60b72ff;
      background: url('images/wenz3.jpeg')
    }

    .text1 {
      text-align: justify;
       line-height: 1.8;
       color: #555;
      font-size: 18px;
    }
  </style>
</head>

<body>
  <div class="navbar">
    <div class="brand">
      <a href="index.php"><i class="fa-solid fa-earth-africa"></i> ስልጤ-Tour</a>
    </div>

    <div class="nav-links">
      <a href="index.php">Home</a>
      <a href="about.php">About Us</a>
      <a href="tour_package.php">Tour Packages</a>
      <a href="contact.php">Contact Us</a>
    </div>

    <div class="nav-auth">
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="dashboard.php"><i class="fa fa-user"></i> My Dashboard</a>
        <a href="logout.php" style="background:#d9534f;">Logout</a>
      <?php else: ?>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
        <a href="admin_login.php" style="background:#333; border:1px solid #555;">Admin</a>
      <?php endif; ?>
    </div>
  </div>


  <div class="all">
    <div class="responsive">
      <div class="gallery">
        <a target="_blank" href="https://siltezonecommunication.gov.et/tourism/silte-cultural-museum">
          <img src="images/muziyem.webp" alt="Forest">
          <img src="images/muziyem1.jfif" alt="Forest">
        </a>
        <div class="desc">
          <h1 class="text">Silete Zone Cultural Museum</h1>
          <h3>The <b>Silte Cultural Museum,</b> located in the zonal capital of Worabe, Ethiopia, offers
            an in-depth look into the heritage and lifestyle of the Silte people.</h3><br>
          <h2>Architecture</h2>
          <h4 class="text1">The museum building itself is a key exhibit, designed to mimic a traditional Silte house. The structure
            features a distinctive arrangement of five smaller huts surrounding a central main house, all under one
            expansive, varnished roof. Internally, the structure is supported by a large central pillar and five smaller
            pillars. The large central pillar is named after Haji Allye, known as the "father of Silte," while the
            smaller pillars are named after other significant historical community leaders like Imam Side, Gerad Abeke,
            Melge Gelo, Haji Allyeh, and Sheh Nasrella.</h4>
          <br>
          <h2>Exhibits and Collections</h2>
          <h4 class="text1">
            Inside the museum, visitors can explore various artifacts and displays that illustrate the community's
            traditional way of life. Collections include traditional household items such as furniture, cooking
            utensils, and floor mats crafted from natural materials like wood, clay, and bamboo. Displays of traditional
            clothing and ornaments provide insight into the Silte aesthetic and style. The museum also showcases a range
            of traditional tools used for farming (like metal plows), hunting, and defense, including shields, spears,
            and javelins. Musical instruments made from reeds, bamboo, and leather drums, which are used during weddings
            and traditional festivals, are also on display.</h4>
        </div>
      </div>
    </div>



    <div class="responsive">
      <div class="gallery">
        <a target="_blank" href="https://www.instagram.com/p/DQkeMJWDWUj/">
          <img src="images/wenz1.jpeg" alt="Riverfront Park">
          <img src="images/wenz2.jpeg" alt="Riverfront View">
        </a>
        <div class="desc">
          <h1 class="text">Worabe Riverfront Park</h1>
          <h3>The <b>Worabe Riverfront Park</b> is a signature urban development project and a premier 
          recreational destination situated along the natural waterways of Worabe, the capital of the Silte Zone.</h3><br>

          <h2>Design and Environmental Restoration</h2>
          <h4 class="text1">The park represents a masterful blend of environmental conservation and modern urban design.
             Historically, the riverbank was a neglected natural corridor, but through extensive restoration, 
             it has been transformed into a "green lung" for the city. The landscape features tiered stone embankments 
             designed to prevent erosion while providing a scenic backdrop for the flowing water. 
             The architectural layout includes sprawling green lawns, decorative stone-paved plazas, 
             and a network of winding pedestrian walkways that allow visitors to stroll the length of the river 
             in a safe, serene, and vehicle-free environment.</h4>
          <br>

          <h2>Amenities and Community Significance</h2>
          <h4 class="text1">
            Beyond its natural beauty, the park is equipped with high-standard amenities that cater to 
            a diverse range of visitors. It features beautifully crafted pergolas, ergonomic wooden and stone benches, 
            and vibrant floral gardens that showcase the region's indigenous plant life. For the community, 
            the park serves as a vital social hub; it is the most popular location in the zone for wedding photography,
             family gatherings, and outdoor festivals. In the evenings, the park is illuminated by eco-friendly lighting, 
             creating a magical atmosphere that encourages nighttime tourism and safe social interaction. It stands as a testament to Worabe's 
             commitment to creating a sustainable, livable, and aesthetically pleasing city for its residents and tourists alike.</h4>
        </div>
      </div>
    </div>



    <div class="responsive">
      <div class="gallery">
        <a target="_blank" href="https://siltezonecommunication.gov.et/tourism/silte-abaya-lake">
          <img src="images/abaya.jfif" alt="Northern Lights">
          <img src="images/abaya1.jfif" alt="Northern Lights">
        </a>
        <div class="desc">
          <h1 class="text">Silte Abaya Lake</h1>
          <h4 class="text1">Silte Abaya Lake is a beautiful, lesser-known gem in Ethiopia's Central Region (Siltʼe Zone) for local
            tourism,
            offering swimming, boating, fish soup (Koroso), and proximity to waterfalls (Lebo, Garore) and hot springs
            (Embab Qoto), distinct from the larger, famous Lake Abaya in the Rift Valley known for crocodiles and its
            reddish water. It's a serene spot for nature lovers, offering relaxation and a taste of local culture near
            Siltʼe communities, while the larger Lake Abaya is known for its vastness and wildlife. </h4>
          <br>
          <h4 class="text1">Key Details The lake is in the Silti Zone, located between the East Silti, Silti, and Lanfuro districts.
            It is approximately 42 km northeast of Worabe town and 152 km from Addis Ababa. The lake covers an area of
            over 1,154 hectares (about 11.54 km²) and has an average depth of up to 9 meters. The main Lake Abaya is
            known for its peculiar reddish-brown waters, a result of a high concentration of suspended sediments. The
            lake and its surroundings support a diverse ecosystem, including around 112 animal species and over 50
            types of aquatic flora. While their numbers have declined, hippos can still be found in the area. The
            region is also home to a variety of bird species. Visitors can enjoy various activities such as swimming,
            boating, and fishing. The region is also known for its local cuisine, especially Koroso fish soup, and
            nearby natural wonders like waterfalls and hot springs.</h4>
        </div>
      </div>
    </div>

    <div class="responsive">
      <div class="gallery">
        <a target="_blank" href="https://siltezonecommunication.gov.et/tourism/lake-hare-sheitan_en">
          <img src="images/here.jfif" alt="Mountains">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d58612.971571231574!2d38.34237335633246!3d8.043276141963599!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x17b36bf30d305ebf%3A0xadb380025182f87b!2sHare%20Shetan%20Crater%20Lake%20HARA%20SHEYTANA!5e0!3m2!1sen!2set!4v1765140965739!5m2!1sen!2set"
            width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>
        </a>

        <div class="desc">
          <h1 class="text">Hare-sheitan Lake</h1>
          <h4 class="text1">Hare-sheitan Lake, alternatively known as Lake Hare Sheitan or Devil's Lake, is a captivating circular
            phreatic explosion crater lake located in the Siltie Zone of Ethiopia, approximately 143 km south of Addis
            Ababa near the town of Butajira. This scenic natural wonder is famous for a unique phenomenon where its
            waters visibly change colors multiple times throughout the day and across different seasons, shifting from
            deep blue-black hues to vibrant greens. Formed by ancient volcanic activity, the lake is cradled within
            dramatic high cliffs that rise 120 to 150 meters above the water surface. <br>
            <br>
            It has an approximate diameter
            of 700 to 880 meters and a depth exceeding 50 meters. The area around the lake is accessible via a short
            1.2 km drive from the main asphalt road and is characterized by dense natural forests and diverse
            wildlife, offering a tranquil environment for visitors. Local legends perhaps contribute to its name, and
            an air of mystery persists as some visitors report that thrown objects seem to disappear without reaching
            the water's surface. A nearby attraction, the Ainage Cave, is located about 1 km away. Hare-sheitan Lake
            is a popular, free-admission tourist destination, praised for its impressive and picturesque views, making
            it a unique stop for travelers exploring the region.</h4>
        </div>
      </div>
    </div>
  </div>

  <div class="clearfix"></div>
  <script>
    document.querySelector('.menu-toggle').addEventListener('click', () => {
      document.querySelector('nav ul').classList.toggle('active');
    });
  </script>

</body>

</html>