<?php session_start();
include 'db.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <title>Ethiopian Tourism</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <div class="navbar">
        <div class="brand">
            <a href="index.php"><i class="fa-solid fa-earth-africa"></i> ስልጤ-Tour</a>
        </div>

        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="about.php">About Us</a>
            <a href="tour_package.php">Tour Packages</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="nav-auth">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="dashboard.php"><i class="fa fa-user"></i> My Dashboard</a>
                <a href="logout.php" style="background:#d9534f;">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
                <a href="admin_login.php" style="background:#333; border:1px solid #555;">Admin</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="hero" style="background: url('images/werabe.jpg') no-repeat center center/cover; height: 500px; display: flex; align-items: center; justify-content: center; color: white; text-align: center;">
        <div style="background: rgba(0,0,0,0.5); padding: 20px; border-radius: 10px;">
            <h1 style="font-size: 3em; margin:0;">ስልጤን ያግኙ - የማይረሳ ጉዞ!</h1>
            <p>ከጥንታዊ ቅርስ እስከ አስደናቂ ተፈጥሮ ድረስ። ጉዞዎን ዛሬውኑ ያስይዙ።</p>
             <a href="tour_package.php" class="btn">see package</a>
        </div>
    </div>

    <div class="container">
        <h2 style="text-align:center; margin-top:30px;">Our Tour Packages</h2>
        <hr style="width: 100px; margin: auto; border: 2px solid #4CAF50;">

        <?php
        $sql = "SELECT * FROM packages";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
        ?>
            <div class="card">
                <img src="images/<?php echo $row['image_file']; ?>" alt="Tour Image">
                <div class="card-body">
                    <h3><?php echo $row['package_name']; ?></h3>
                    <p><?php echo substr($row['description'], 0, 800); ?>...</p>
                    <p><strong>Price: <?php echo $row['price']; ?> ETB</strong></p>
                    <a href="book.php?id=<?php echo $row['package_id']; ?>" class="btn">Book Now</a>
                </div>
            </div>
        <?php } ?>
    </div>
</body>

</html>