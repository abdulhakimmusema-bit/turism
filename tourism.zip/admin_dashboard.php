<?php
session_start();
include 'db.php';
// አድሚን መሆኑን ማረጋገጥ
if (!isset($_SESSION['admin_id'])) { header("Location: admin_login.php"); exit; }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .admin-panel { display: flex; }
        .sidebar { width: 250px; background: #2c3e50; min-height: 100vh; color: white; padding: 20px; }
        .sidebar a { display: block; color: #bdc3c7; padding: 15px; text-decoration: none; border-bottom: 1px solid #34495e; }
        .sidebar a:hover { color: white; background: #34495e; }
        .main-content { flex: 1; padding: 20px; }
        .stat-box { background: #3498db; color: white; padding: 20px; width: 23%; float: left; margin: 1%; text-align: center; border-radius: 5px; }
        .clearfix::after { content: ""; clear: both; display: table; }
    </style>
</head>
<body>
    <div class="admin-panel">
        <div class="sidebar">
            <h3><i class="fa fa-cogs"></i> Admin Panel</h3>
            <a href="admin_dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a>
            <a href="manage_packages.php"><i class="fa fa-map"></i> Manage Packages</a> 
            <a href="manage_bookings.php"><i class="fa fa-book"></i> Manage Bookings</a>
            <a href="manage_users.php"><i class="fa fa-users"></i> Manage Users</a>
            <a href="view_messages.php"><i class="fa fa-envelope"></i> Manage Messages</a>
            <a href="logout.php" style="color:#e74c3c;"><i class="fa fa-sign-out"></i> Logout</a>
        </div>
        
        <div class="main-content">
            <h1>Welcome, Admin!</h1>
            
            <div class="clearfix">
                <div class="stat-box">
                    <h3>Total Users</h3>
                    <h1><?php echo $conn->query("SELECT * FROM users")->num_rows; ?></h1>
                </div>
                <div class="stat-box" style="background:#27ae60;">
                    <h3>Total Bookings</h3>
                    <h1><?php echo $conn->query("SELECT * FROM bookings")->num_rows; ?></h1>
                </div>
                <div class="stat-box" style="background:#e67e22;">
                    <h3>Packages</h3>
                    <h1><?php echo $conn->query("SELECT * FROM packages")->num_rows; ?></h1>
                </div>
                <div class="stat-box" style="background:#9b59b6;">
                    <h3>New Messages</h3>
                    <h1><?php echo $conn->query("SELECT * FROM contact_messages")->num_rows; ?></h1>
                </div>
            </div>
        </div>
    </div>
</body>
</html>